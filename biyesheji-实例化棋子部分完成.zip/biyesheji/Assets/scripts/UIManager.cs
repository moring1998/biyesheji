﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 控制页面之间的显示与页面跳转、加载游戏、按钮的触发方法，在GameManager之后实例化
/// </summary>
public class UIManager : MonoBehaviour
{
    public static UIManager Instance
    {
        get;private set;
    }
    public GameObject[] panels;//0.登录界面  1.主菜单  2.单机模式游戏界面  3.联网模式游戏界面 
    public Text TipUIText;//当前需要改变具体文本的显示UI
    public Text[] TipUITexts;//两个对应显示UI的引用
    private GameManager gameManager;



    // Start is called before the first frame update
    void Start()
    {
        Instance = this;
        gameManager = GameManager.instance;
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    #region 页面跳转
    /// <summary>
    /// 单机模式
    /// </summary>
    public void standaloneMode()
    {
        LoadGame();
    }

    /// <summary>
    /// 联网模式
    /// </summary>
    public void NetWorkingMode()
    {
        panels[1].SetActive(false);
        panels[3].SetActive(true);
    }

    /// <summary>
    ///  退出游戏
    /// </summary>
    public void ExitGame()
    {
        Application.Quit();
    }
    #endregion

    #region 加载游戏
    private void LoadGame()
    {
        gameManager.ResetGame();
        SetUI();
        panels[2].SetActive(true);
    }

    public void SetUI()
    {
        panels[1].SetActive(true);
    }
    #endregion

    #region 游戏中的UI方法
    /// <summary>
    /// 悔棋
    /// </summary>
    public void UnDo()
    {

    }
    /// <summary>
    /// 重玩
    /// </summary>
    public void Replay()
    {

    }
    /// <summary>
    /// 返回
    /// </summary>
    public void ReturnToMain()
    {

    }
    /// <summary>
    /// 下棋轮次及提示
    /// </summary>
    public void ShowTip(string str)
    {
        TipUIText.text = str;
    }
    /// <summary>
    /// 联网模式下的开始
    /// </summary>
    public void StartNetWorKingMode()
    {

    }
    /// <summary>
    /// 认输
    /// </summary>
    public void GiveUp()
    {

    }
    #endregion
}
